package your.mod.mixin;

import com.gregtechceu.gtceu.common.blockentity.CableBlockEntity;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyNet;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyNetHandler;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyRoutePath;
import com.gregtechceu.gtceu.utils.GTUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import your.mod.energy.SinkCache;
import your.mod.energy.SinkState;

import java.util.List;

@Mixin(value = EnergyNetHandler.class, remap = false)
public abstract class EnergyNetHandlerMixin {
@Shadow private EnergyNet net;
    @Shadow private CableBlockEntity cable;
    @Shadow private Direction facing;
    @Shadow private boolean transfer;


    /**
     * @author henry
     * @reason Stop repeated per-machine sink probing across the same EnergyNet by caching endpoint handlers (multi-tick)
     *         and per-tick sink capacity state.
     */
    @Overwrite(remap = false)
    public long acceptEnergyFromNetwork(Direction side, long voltage, long amperage) {
        // Match GTCEu's recursion guard. Some endpoints can trigger nested transfers during accept.
        if (transfer) {
            return 0;
        }

        // Match GTCEu's side handling: if null, fall back to our facing (or refuse if also null).
        if (side == null) {
            if (facing == null) return 0;
            side = facing;
        }

        if (amperage <= 0 || net == null || cable == null) {
            return 0;
        }

        List<EnergyRoutePath> routes = net.getNetData(cable.getPipePos());
        if (routes.isEmpty()) return 0;

        Level level = net.getLevel();
        long tick = level.getGameTime();
        SinkCache cache = SinkCache.get(net, tick);
long remaining = amperage;
        long acceptedTotal = 0;

        for (EnergyRoutePath path : routes) {
            if (remaining <= 0) break;

            // If the route loses all voltage, skip it (vanilla GTCEu behaviour).
            if (path.getMaxLoss() >= voltage) {
                continue;
            }

            // Preserve original "skip self" behavior
            if (cable.getPipePos().equals(path.getTargetPipePos()) && side == path.getTargetFacing()) {
                continue;
            }

            // Compute voltage delivered to the endpoint, applying max loss.
            // IMPORTANT: do NOT "clamp" voltage down to a lower-tier cable's max voltage.
            // Lower-tier cables are supposed to heat up / burn out under over-voltage; they do not
            // behave like a step-down transformer. Clamping here prevents correct over-voltage
            // behavior downstream (e.g. lower-tier hatches exploding).
            long deliveredVoltage = voltage - path.getMaxLoss();
            boolean invalidPath = false;
            for (com.gregtechceu.gtceu.common.blockentity.CableBlockEntity seg : path.getPath()) {
                long segMax = seg.getMaxVoltage();
                if (segMax < voltage) {
                    int heat = (int) (Math.log((double) (GTUtil.getTierByVoltage(voltage) - GTUtil.getTierByVoltage(segMax)))
                            * 45.0d + 36.5d);
                    seg.applyHeat(heat);
                    invalidPath = seg.isInValid();
                    if (invalidPath) break;
                }
            }
            if (invalidPath) {
                continue;
            }

            // Endpoint (machine) position and insertion side
            BlockPos endpointPos = path.getTargetPipePos().relative(path.getTargetFacing());
            Direction insertSide = path.getTargetFacing().getOpposite();

            SinkState sink = cache.getOrCompute(net, path, level, endpointPos, insertSide, deliveredVoltage);
            if (!sink.valid || sink.remainingAmps <= 0) continue;

            long toSend = Math.min(remaining, sink.remainingAmps);

            long accepted;
            transfer = true;
            try {
                accepted = sink.handler.acceptEnergyFromNetwork(insertSide, deliveredVoltage, toSend);
            } finally {
                transfer = false;
            }

            if (accepted > 0) {
                // Preserve GTCEu cable statistics (Jade/WTHIT/TOP live amperage) and over-amp heat behavior.
                //
                // Server-side mitigation for remote-client stutter:
                // - Batch per-segment accounting once per tick (instead of per-transfer).
                // - Skip tooltip-visible counter updates when no players are nearby, while keeping heat/burn safety correct.
                long voltageTraveled = voltage;
                for (com.gregtechceu.gtceu.common.blockentity.CableBlockEntity seg : path.getPath()) {
                    voltageTraveled -= seg.getNodeData().getLossPerBlock();
                    if (voltageTraveled <= 0) break;
                    if (level instanceof net.minecraft.server.level.ServerLevel sl) {
                        your.mod.energy.CableAmperageAccumulator.record(sl, seg, accepted, voltageTraveled);
                    }
                }
                sink.remainingAmps -= accepted;
                remaining -= accepted;
                acceptedTotal += accepted;
            }
        }

        net.addEnergyFluxPerSec(acceptedTotal * voltage);
        return acceptedTotal;
    }
}
