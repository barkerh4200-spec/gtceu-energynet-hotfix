package your.mod.energy;

import com.gregtechceu.gtceu.api.capability.IEnergyContainer;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyNet;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyRoutePath;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * Multi-tick cache of endpoint -> resolved IEnergyContainer handler.
 *
 * Goal: avoid repeated capability resolution (Level#getBlockEntity, getCapability, LazyOptional.resolve)
 * on every tick / every producer when distributing energy across the same EnergyNet.
 *
 * Correctness:
 * - Cache is scoped to a specific EnergyNet instance (GTCEu replaces nets on rebuild).
 * - Entries are invalidated locally on neighbor updates (see EnergyNetMixin).
 * - Entries are also validated by checking the current BlockEntity identity before use.
 */
public final class HandlerCache {

    private HandlerCache() {}

    /**
     * Hot path: used by energynet delivery on the main server thread.
     *
     * WeakHashMap + synchronization shows up heavily in profiles under load.
     * EnergyNet instances are long-lived while their chunks are loaded, and we also clear
     * these caches on net rebuild/dirty events.
     */
    private static final Reference2ObjectOpenHashMap<EnergyNet, PerNet> PER_NET =
            new Reference2ObjectOpenHashMap<>();

    // Tiny single-entry hot cache to avoid hashing on repeated calls within the same tick.
    private static EnergyNet LAST_NET;
    private static PerNet LAST_PER_NET;

    private static final class Cached {
        final BlockEntity be;
        final IEnergyContainer handler; // may be null

        Cached(BlockEntity be, IEnergyContainer handler) {
            this.be = be;
            this.handler = handler;
        }
    }

    private static final class PerNet {
        final Long2ObjectOpenHashMap<Cached> map = new Long2ObjectOpenHashMap<>();
    }

    private static PerNet perNet(EnergyNet net) {
        if (net == LAST_NET && LAST_PER_NET != null) {
            return LAST_PER_NET;
        }
        PerNet pn = PER_NET.get(net);
        if (pn == null) {
            pn = new PerNet();
            PER_NET.put(net, pn);
        }
        LAST_NET = net;
        LAST_PER_NET = pn;
        return pn;
    }

    /**
     * Resolve (and cache) the handler for a given endpoint.
     *
     * @param net EnergyNet instance (cache scope)
     * @param level Level
     * @param endpointPos block position of the machine/endpoint
     * @param insertSide side from which energy is inserted into the endpoint
     * @param path route path (used as resolution source; avoids signature drift)
     */
    public static IEnergyContainer get(EnergyNet net, Level level, BlockPos endpointPos, Direction insertSide, EnergyRoutePath path) {
        long key = KeyUtil.packPosSide(endpointPos, insertSide);
        PerNet pn = perNet(net);

        Cached cached = pn.map.get(key);

        BlockEntity currentBe = level.getBlockEntity(endpointPos);
        if (cached != null && cached.be == currentBe) {
            return cached.handler;
        }

        // Refresh: resolve via route path (internally does the capability lookup).
        IEnergyContainer handler = path.getHandler(level);

        pn.map.put(key, new Cached(currentBe, handler));
        return handler;
    }

    /**
     * Local invalidation around a position (called from EnergyNetMixin).
     * Removes cached handlers for the given position and its 6 neighbors, for all sides.
     */
    public static void invalidateAround(EnergyNet net, BlockPos fromPos) {
        if (net == null || fromPos == null) return;
        PerNet pn = PER_NET.get(net);
        if (pn == null) return;

        // fromPos and its neighbors
        invalidatePosAllSides(pn, fromPos);
        for (Direction d : Direction.values()) {
            invalidatePosAllSides(pn, fromPos.relative(d));
        }
    }

    private static void invalidatePosAllSides(PerNet pn, BlockPos pos) {
        long base = pos.asLong() << 3;
        for (int s = 0; s < 6; s++) {
            pn.map.remove(base | (long)s);
        }
    }

    /** Full clear for a given net (optional utility). */
    public static void clear(EnergyNet net) {
        if (net == null) return;
        PER_NET.remove(net);
        if (net == LAST_NET) {
            LAST_NET = null;
            LAST_PER_NET = null;
        }
    }
}
