package your.mod.energy;


import com.gregtechceu.gtceu.api.capability.IEnergyContainer;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyNet;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyRoutePath;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public final class SinkState {

    public final IEnergyContainer handler;
    public final boolean valid;
    public long remainingAmps;

    /** Whether this result should be cached for the remainder of the tick. */
    public final boolean cacheable;

    private SinkState(IEnergyContainer handler, boolean valid, long remainingAmps, boolean cacheable) {
        this.handler = handler;
        this.valid = valid;
        this.remainingAmps = remainingAmps;
        this.cacheable = cacheable;
    }

    public static SinkState compute(
            EnergyNet net,
            EnergyRoutePath path,
            Level level,
            BlockPos endpointPos,
            Direction insertSide,
            long voltage
    ) {
        IEnergyContainer handler = HandlerCache.get(net, level, endpointPos, insertSide, path);
        if (handler == null) return new SinkState(null, false, 0, true);

        // Over-voltage handling must match GTCEu semantics:
        // - For EU machines/hatches, GTCEu triggers failure/explosion *inside* acceptEnergyFromNetwork.
        //   We must not short-circuit the call, even if the endpoint currently has little/no storage space.
        // - For FE sinks wrapped by GTCEu's EUToFEProvider.GTEnergyWrapper, there is no explosion semantics,
        //   so we may treat over-voltage as a stable negative.
        long maxInputVoltage = handler.getInputVoltage();
        boolean isFeWrapper = handler instanceof com.gregtechceu.gtceu.api.capability.compat.EUToFEProvider.GTEnergyWrapper;
        boolean isOverVoltage = maxInputVoltage > 0 && voltage > maxInputVoltage;
        if (isOverVoltage && isFeWrapper) {
            return new SinkState(handler, false, 0, true);
        }

        if (!handler.inputsEnergy(insertSide)) return new SinkState(handler, false, 0, true);

        long maxAmps = handler.getInputAmperage();
        if (maxAmps <= 0) {
            return new SinkState(handler, false, 0, true);
        }

        if (voltage > 0) {
            long euSpace = handler.getEnergyCanBeInserted();
            long ampsByStorage = euSpace / voltage;

            // IMPORTANT:
            // For EU endpoints under over-voltage, we must allow the acceptEnergyFromNetwork call to happen
            // so GTCEu can execute its explosion/failure behavior.
            // Some hatches have relatively small internal buffers; with huge input voltage,
            // euSpace / voltage may be 0 even when the endpoint is empty.
            // If we treat that as "invalid" here, we will never call acceptEnergyFromNetwork, and the hatch
            // will never explode (observed regression).
            if (ampsByStorage <= 0) {
                if (isOverVoltage && !isFeWrapper) {
                    // Force at least one attempt so the endpoint can process over-voltage (explode).
                    return new SinkState(handler, true, 1, true);
                }

                // Storage is full *right now*; space can open later in the same tick after the machine consumes energy.
                // Do not cache this negative result for the whole tick, or we can under-supply and cause machines to pause.
                return new SinkState(handler, false, 0, false);
            }

            maxAmps = Math.min(maxAmps, ampsByStorage);
        }

        return new SinkState(handler, true, maxAmps, true);
    }
}
