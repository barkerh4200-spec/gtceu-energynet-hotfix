package your.mod.energy;

import com.gregtechceu.gtceu.common.pipelike.cable.EnergyNet;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyRoutePath;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

/**
 * Per-net, per-tick sink state cache.
 *
 * Values include remaining amps for THIS tick and voltage (storage clamp).
 * Uses HandlerCache for multi-tick handler resolution.
 */
public final class SinkCache {

    /**
     * Hot path: called from {@code EnergyNetHandler.acceptEnergyFromNetwork()} for every output hatch tick.
     *
     * The energynet delivery happens on the main server thread, so we can avoid the overhead of
     * {@link java.util.WeakHashMap} (ReferenceQueue + synchronized access) and use an identity map.
     *
     * This cache is still conservative: it is per-net and per-tick, and is invalidated alongside
     * the rest of our handler/sink caches when the net is marked dirty.
     */
    private static final Reference2ObjectOpenHashMap<EnergyNet, SinkCache> NET_CACHE =
            new Reference2ObjectOpenHashMap<>();

    // Tiny single-entry hot cache to avoid hashing on repeated calls within the same tick.
    private static EnergyNet LAST_NET;
    private static long LAST_TICK;
    private static SinkCache LAST_CACHE;

    private final Long2ObjectOpenHashMap<SinkState> sinks = new Long2ObjectOpenHashMap<>();
    private final long tick;

    private SinkCache(long tick) {
        this.tick = tick;
    }

    public static SinkCache get(EnergyNet net, long tick) {
        // Fast-path: same net and tick as last call.
        if (net == LAST_NET && tick == LAST_TICK && LAST_CACHE != null) {
            return LAST_CACHE;
        }

        SinkCache cache = NET_CACHE.get(net);
        if (cache == null || cache.tick != tick) {
            cache = new SinkCache(tick);
            NET_CACHE.put(net, cache);
        }

        LAST_NET = net;
        LAST_TICK = tick;
        LAST_CACHE = cache;
        return cache;
    }

    /**
     * Conservative invalidation hook used when the net is marked dirty.
     */
    public static void clear(EnergyNet net) {
        NET_CACHE.remove(net);
        if (net == LAST_NET) {
            LAST_NET = null;
            LAST_TICK = 0L;
            LAST_CACHE = null;
        }
    }

    public SinkState getOrCompute(
            EnergyNet net,
            EnergyRoutePath path,
            Level level,
            BlockPos endpointPos,
            Direction insertSide,
            long voltage
    ) {
        long posSide = KeyUtil.packPosSide(endpointPos, insertSide);
        long key = KeyUtil.mix(posSide, voltage);

        SinkState s = sinks.get(key);
        if (s != null) return s;

        s = SinkState.compute(net, path, level, endpointPos, insertSide, voltage);
        if (s.cacheable) sinks.put(key, s);
        return s;
    }
}
