package your.mod.mixin;

import com.gregtechceu.gtceu.common.blockentity.CableBlockEntity;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyNet;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyNetHandler;
import com.gregtechceu.gtceu.common.pipelike.cable.EnergyRoutePath;
import com.gregtechceu.gtceu.utils.GTUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import your.mod.energy.CableAmperageAccumulator;
import your.mod.energy.SinkCache;
import your.mod.energy.SinkState;

import java.util.List;

/**
 * EnergyNet delivery hotfix:
 *  - Keeps the 7% TPS architecture (SinkCache + HandlerCache + lazy invalidation) to avoid repeated endpoint probing.
 *  - Restores vanilla GTCEu 7.4.0 semantics for:
 *      * route max-loss filtering
 *      * voltage drop by lossPerBlock (lossy vs lossless cables)
 *      * overvoltage heating and invalidation
 *      * voltage clamping to the weakest surviving cable segment (vanilla behaviour)
 *  - Uses tick-end cable amperage batching WITHOUT any player-proximity gating.
 */
@Mixin(value = EnergyNetHandler.class, remap = false)
public abstract class EnergyNetHandlerMixin {

    @Shadow private EnergyNet net;
    @Shadow private CableBlockEntity cable;

    // Fields exist in GTCEu 7.4.0 EnergyNetHandler; used as vanilla recursion/side guards.
    @Shadow private Direction facing;
    @Shadow private boolean transfer;

    /**
     * @author henry
     * @reason Preserve performance optimizations while matching vanilla loss + overvoltage enforcement.
     */
    @Overwrite(remap = false)
    public long acceptEnergyFromNetwork(Direction side, long voltage, long amperage) {
        // Match GTCEu recursion guard.
        if (transfer) return 0;

        // Match GTCEu side handling.
        if (side == null) {
            if (facing == null) return 0;
            side = facing;
        }

        if (amperage <= 0 || voltage <= 0 || net == null || cable == null) {
            return 0;
        }

        final Level level = net.getLevel();
        if (!(level instanceof ServerLevel serverLevel)) {
            // EnergyNetHandler is server-side in normal operation, but guard anyway.
            return 0;
        }

        // Vanilla semantics: if a cable itself is exposed to a higher voltage than its rating,
        // it should heat up / burn even if there are currently no valid endpoints (routes).
        final long selfMax = cable.getMaxVoltage();
        if (selfMax < voltage) {
            final int tierDiff = GTUtil.getTierByVoltage(voltage) - GTUtil.getTierByVoltage(selfMax);
            if (tierDiff > 0) {
                final int heat = (int) (Math.log((double) tierDiff) * 45.0d + 36.5d);
                cable.applyHeat(heat);
            }
            if (cable.isInValid()) {
                return 0;
            }
            // If it survived, clamp what can proceed through the net to this cable's rating.
            voltage = Math.min(voltage, selfMax);
        }

        final List<EnergyRoutePath> routes = net.getNetData(cable.getPipePos());
        if (routes.isEmpty()) return 0;
final long tick = serverLevel.getGameTime();
        final SinkCache cache = SinkCache.get(net, tick);

        long remaining = amperage;
        long acceptedTotal = 0;

        for (EnergyRoutePath path : routes) {
            if (remaining <= 0) break;

            // Vanilla: if the route loses all voltage, skip.
            if (path.getMaxLoss() >= voltage) {
                continue;
            }

            // Vanilla: skip self
            if (cable.getPipePos().equals(path.getTargetPipePos()) && side == path.getTargetFacing()) {
                continue;
            }

            // Vanilla: delivered voltage starts at (source voltage - route max loss)
            long deliveredVoltage = voltage - path.getMaxLoss();

            // Vanilla: walk cable segments to apply overvoltage heating and clamp delivered voltage
            boolean invalidPath = false;
            for (CableBlockEntity seg : path.getPath()) {
                final long segMax = seg.getMaxVoltage();

                if (segMax < voltage) {
                    // Heat calculation matches the feature build; uses tier difference log scaling.
                    // (This is intentionally the same shape as GTCEu uses.)
                    final int tierDiff = GTUtil.getTierByVoltage(voltage) - GTUtil.getTierByVoltage(segMax);
                    // tierDiff is > 0 here, but guard anyway.
                    if (tierDiff > 0) {
                        final int heat = (int) (Math.log((double) tierDiff) * 45.0d + 36.5d);
                        seg.applyHeat(heat);
                    }

                    if (seg.isInValid()) {
                        invalidPath = true;
                        break;
                    }
                }

                // Vanilla clamp: weakest surviving segment caps what the endpoint sees.
                if (segMax < deliveredVoltage) {
                    deliveredVoltage = segMax;
                }
            }
            if (invalidPath || deliveredVoltage <= 0) {
                continue;
            }

            // Endpoint (machine) position and insertion side
            final BlockPos endpointPos = path.getTargetPipePos().relative(path.getTargetFacing());
            final Direction insertSide = path.getTargetFacing().getOpposite();

            // Per-tick sink capacity cache keyed by deliveredVoltage (post-loss + clamp)
            final SinkState sink = cache.getOrCompute(net, path, serverLevel, endpointPos, insertSide, deliveredVoltage);
            if (!sink.valid || sink.remainingAmps <= 0) continue;

            final long toSend = Math.min(remaining, sink.remainingAmps);

            long accepted;
            transfer = true;
            try {
                accepted = sink.handler.acceptEnergyFromNetwork(insertSide, deliveredVoltage, toSend);
            } finally {
                transfer = false;
            }

            if (accepted > 0) {
                // Vanilla: apply per-segment amperage tracking using traveled voltage (lossPerBlock each step).
                long voltageTraveled = voltage;
                for (CableBlockEntity seg : path.getPath()) {
                    voltageTraveled -= seg.getNodeData().getLossPerBlock();
                    if (voltageTraveled <= 0) break;
                    CableAmperageAccumulator.record(serverLevel, seg, accepted, voltageTraveled);
                }

                sink.remainingAmps -= accepted;
                remaining -= accepted;
                acceptedTotal += accepted;
            }
        }

        // Match existing behaviour: flux stats are based on source voltage.
        net.addEnergyFluxPerSec(acceptedTotal * voltage);
        return acceptedTotal;
    }
}
