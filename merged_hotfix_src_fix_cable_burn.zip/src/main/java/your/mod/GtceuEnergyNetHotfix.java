package your.mod;

import net.minecraftforge.fml.common.Mod;

@Mod("gtceuenergynethotfix")
public final class GtceuEnergyNetHotfix {}
